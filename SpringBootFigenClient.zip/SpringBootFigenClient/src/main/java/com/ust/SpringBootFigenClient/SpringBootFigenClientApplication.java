package com.ust.SpringBootFigenClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootFigenClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootFigenClientApplication.class, args);
	}

}
