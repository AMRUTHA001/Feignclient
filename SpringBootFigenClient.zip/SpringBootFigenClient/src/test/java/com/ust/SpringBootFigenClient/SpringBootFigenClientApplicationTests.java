package com.ust.SpringBootFigenClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFigenClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
