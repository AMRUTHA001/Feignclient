package com.ust.BookServicefeign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookServicefeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookServicefeignApplication.class, args);
	}

}
