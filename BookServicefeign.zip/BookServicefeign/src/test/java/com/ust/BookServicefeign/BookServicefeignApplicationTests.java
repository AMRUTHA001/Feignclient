package com.ust.BookServicefeign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookServicefeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
