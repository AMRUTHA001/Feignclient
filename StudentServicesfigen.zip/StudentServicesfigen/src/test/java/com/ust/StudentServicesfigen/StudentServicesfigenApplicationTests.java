package com.ust.StudentServicesfigen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentServicesfigenApplicationTests {

	@Test
	void contextLoads() {
	}

}
