package com.ust.StudentServicesfigen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentServicesfigenApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentServicesfigenApplication.class, args);
	}

}
